/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package afit;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import javax.swing.JPanel;
import java.awt.event.MouseEvent;
import java.awt.AWTEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

/**
 * Panel that graphically shows the jog display and
 * allows for jogging using the mouse.
 *
 * @author dwhitman
 */
public class JoystickDisplayPanel extends JPanel {
	final static float NO_CHANGE = -2;
	int width = 0;;
	int height = 0;
	int cursorX = 0;
	int cursorY = 0;

	/**
	 * Constructor that just inializes the panel with the
	 * cursor at the origin.
	 */
	public JoystickDisplayPanel() {
		super();
		enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK | AWTEvent.MOUSE_EVENT_MASK);
	}

	/**
	 * Updates the display with the cursor at the current
	 * position.
	 *
	 * @param	g	graphics to which to draw
	 */
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g); 

		Graphics2D g2d = (Graphics2D)g;

		Dimension size = getSize();
		Insets insets = getInsets();
		width =  size.width - insets.left - insets.right + 1;
		height =  size.height - insets.top - insets.bottom + 1;

		// Draw grid
		final int gridSize = 15;
		g2d.setColor(Color.lightGray);
		for(int i = gridSize; i <= width-gridSize/2; i += gridSize) {
			g2d.drawLine(i, 0, i, height);
			g2d.drawLine(0, i, width, i);
		}

		// Draw axes
		final int axesThickness = 1;
		g2d.setColor(Color.black);
		g2d.fillRect(0, height/2-axesThickness, width, 2*axesThickness + 1);
		g2d.fillRect(width/2-axesThickness, 0, 2*axesThickness + 1, height);

		// Draw cursor
		final int cursorRadius = 10;
		g2d.setColor(Color.red);
		g2d.setStroke(new BasicStroke(2));
		g2d.draw(new Ellipse2D.Float(width/2 + cursorX - cursorRadius, height/2 + cursorY - cursorRadius, cursorRadius*2, cursorRadius*2));
		
	}

	/**
	 * Event handler that deals with clicking and releasing of
	 * mouse buttons.
	 *
	 * @param	evt	event object
	 */
	@Override
	protected void processMouseEvent(MouseEvent evt) {
		switch(evt.getID()) {
		case MouseEvent.MOUSE_PRESSED :
			// Set the cursor to the clicked position
			cursorX = evt.getX()-width/2;
			cursorY = evt.getY()-height/2;
			repaint();
			break;
		case MouseEvent.MOUSE_RELEASED : 
			// Set the cursor to the origin
			setValue(0, 0);
			break;
		}
	}

	/**
	 * Event handler that deals with mouse motion.
	 *
	 * @param	evt	event object
	 */
	@Override
	protected void processMouseMotionEvent(MouseEvent evt) {
		if(evt.getID() == MouseEvent.MOUSE_DRAGGED) {
			// Set the cursor to the mouse cursor position
			cursorX = evt.getX()-width/2;;
			cursorY = evt.getY()-height/2;
			
			// Bounds checking
			if(cursorX < -width/2)
				cursorX = -width/2;
			else if(cursorX > width/2)
				cursorX = width/2;
			if(cursorY < -height/2)
				cursorY = -height/2;
			else if(cursorY > height/2)
				cursorY = height/2;

			repaint();
		}
	}

	/**
	 * Sets the normalized cursor position.
	 *
	 * @param	x	normalized x coordinate of the cursor ranging from -1 to 1
	 * @param	y	normalized y coordinate of the cursor ranging from -1 to 1
	 */
	public void setValue(float x, float y) {
		if(x < -1)
			x = -1;
		else if(x > 1)
			x = 1;
		cursorX = Math.round((float)width/2*x);

		if(y < -1)
			y = -1;
		else if(y > 1)
			y = 1;
		cursorY = -Math.round((float)height/2*y);

		repaint();
	}

	/**
	 * Retrieves the cursor value.
	 *
	 * @return	the normalized cursor value with x and y ranging from -1 to 1
	 */
	public Point2D.Float getValue() {
		if(width == 0 || height == 0)
			return new Point2D.Float(0,0);

		return new Point2D.Float((float)cursorX/((float)width/2), -(float)cursorY/((float)height/2));
	}
}

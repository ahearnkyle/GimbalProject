package afit.util;

import afit.util.GimbalsConfig.Gimbal;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Class which contains the configuration
 * information for the gimbals, namely addresses
 * and port numbers. It is nothing more than an
 * array of <code>Gimbal</code> objects.
 *
 * @author	dwhitman
 */
public class GimbalsConfig
	extends ArrayList<Gimbal>
{
	/**
	 * Class which represents a single gimbal configuration,
	 * namely an address and port number.
	 */
	public static class Gimbal
		implements Serializable, Cloneable
	{
		String address;
		int port;
	  
		/** Constructs the object with the specified address and port number **/
		public Gimbal(String addr, int p) {
			address = addr;
			port = p;
		}

		/**
		 * Accessor method.
		 *
		 * @return	address (hostname or IP address in string form)
		 */
		public String getAddress() {
			return address;
		}

		/**
		 * Accessor method.
		 *
		 * @return	the port number
		 */
		public int getPort() {
			return port;
		}

		/**
		 * Converts the address and port number to a string.
		 *
		 * @return	string representation of address and port number
		 */
		@Override
		public String toString() {
			return address + ":" + port;
		}

		/**
		 * Clone method. Creates an identical object.
		 *
		 * @return	cloned object
		 */
		@Override
		public Gimbal clone() {
			return new Gimbal(address, port);
		}
	}

	/**
	 * Clone method. Creates an identical object.
	 *
	 * @return	cloned object
	 */
	@Override
	public GimbalsConfig clone() {
		GimbalsConfig gc = new GimbalsConfig();
		for(int i = 0; i < size(); i++)
			gc.add(get(i).clone());
		return gc;
	}
}

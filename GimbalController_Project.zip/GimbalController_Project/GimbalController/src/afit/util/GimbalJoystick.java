package afit.util;

import java.io.IOException;
import com.centralnexus.input.*;

/**
 * Class which  handles joystick input for gimbal control
 */
public class GimbalJoystick
{
	boolean axisChanged = false;
	float lastPan = 0;
	float lastTilt = 0;
	float lastSens = 0;
	int pressedMask = 0;
	int lastPressed = 0;
	int bClicked = 0;
	boolean first;

	Joystick jstick;
	GimbalJoystickConfig jconfig;

	/**
	 * Constructs object with a specified joystick configuration
	 *
	 * @param	config	joystick configuration tied to the joystick
	 * @param	jid		ID of the joystick to use
	 */
	public GimbalJoystick(GimbalJoystickConfig config, int jid)
		throws IOException
	{
		this(config, null);

		if(jid > 0)
			jstick = Joystick.createInstance(jid);
		else
			jstick = Joystick.createInstance();
	}

	/**
	 * Constructs object with specified joystick configuration
	 * and existing Joystick object.
	 *
	 * @param	config	joystick configuration tied to the joystick
	 * @param	js		<code>Joystick</code> object to use
	 */
	public GimbalJoystick(GimbalJoystickConfig config, Joystick js)	{
		jconfig = config;
		jstick = js;
		first = true;
	}

	/**
	 * Sets the joystick object to use.
	 *
	 * @param	js	<code>Joystick</code> object to use
	 */
	public void setJoystick(Joystick js) {
		if(js != null)
			jstick = js;
	}

	/**
	 * Returns the <code>Joystick</code> object currently in use.
	 *
	 * @return	<code>Joystick</code> object in use
	 */
	public Joystick getJoystick() {
		return jstick;
	}

	/**
	 * Returns the configuration currently in use.
	 *
	 * @return	joystick configuration in use
	 */
	public GimbalJoystickConfig getJoystickConfig() {
		return jconfig;
	}

	/**
	 * Polls the joystick and updated axis values and button
	 * presses.
	 */
	public void poll()
	{
		jstick.poll();
		pressedMask = jstick.getButtons();

		if(!first)
			bClicked = (lastPressed ^ pressedMask) & pressedMask;
		first = false;

		float pan = getAxis(GimbalJoystickConfig.AXIS_PAN);
		float tilt = getAxis(GimbalJoystickConfig.AXIS_TILT);
		float sens = getAxis(GimbalJoystickConfig.AXIS_SENS);

		// Has either axis changed?
		if(pan != lastPan || tilt != lastTilt || sens != lastSens)
			axisChanged = true;
		else
			axisChanged = false;

		lastPressed = pressedMask;
		lastPan = pan;
		lastTilt = tilt;
		lastSens = sens;
	}

	/**
	 * Resturns the value for the requested axis.
	 *
	 * @param	axis	axis constant from <code>GimbalJoystickConfig</code>
	 * @return			value of the axis ranging from -1 to 1
	 */
	public float getAxis(int axis)
	{
		switch(jconfig.getAxisButton(axis))
		{
			case GimbalJoystickConfig.JS_AXIS_X :
				return jstick.getX();
			case GimbalJoystickConfig.JS_AXIS_Y :
				return jstick.getY();
			case GimbalJoystickConfig.JS_AXIS_Z :
				return jstick.getZ();
			case GimbalJoystickConfig.JS_AXIS_U :
				return jstick.getU();
			case GimbalJoystickConfig.JS_AXIS_V :
 				return jstick.getV();
			case GimbalJoystickConfig.JS_AXIS_R :
				return jstick.getR();
		}

		return 0;
	}

	/**
	 * Query whether or not an either axis has changed since
	 * the last poll.
	 *
	 * @return	<code>true</code> if an axis has changed and <code>false</code> otherwise
	 */
	public boolean axisChanged() {
		return axisChanged;
	}

	/**
	 * Returns if a button has been pressed since the last poll.
	 *
	 * @param	btn	button constant from <code>GimbalJoystickConfig</code>
	 * @return	<code>true</code> if the button was pressed and <code>false</code> otherwise
	 */
	public boolean buttonPressed(int btn)
	{
		return (bClicked & jconfig.getAxisButton(btn)) != 0;
	}

	/**
	 * Returns if a button was pressed given a button mask.
	 *
	 * @param	btn	button mask to test
	 * @return	<code>true</code> if the button was pressed and <code>false</code> otherwise
	 */
	public boolean buttonPressedRaw(int btn)
	{
		return (bClicked & btn) != 0;
	}
}

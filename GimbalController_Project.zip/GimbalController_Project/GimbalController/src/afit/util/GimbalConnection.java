/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package afit.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.awt.geom.Point2D;

/**
 * Provides a connection to a gimbal and an interface
 * to send and recieve commands from it. For a more
 * detailed explanation of the commands, refer to
 * the Integrated Controller Protocol Manual.
 *
 * @author dwhitman
 */
public class GimbalConnection {
	/**
	 * Encapsulates the status of a gimbal
	 */
	public class GimbalStatus {
		/** No activity for the direction **/
		final static public int NONE = 0;
		/** Moving in the direction **/
		final static public int MOVING = 1;
		/** In soft limit region **/
		final static public int SOFT_LIMIT = 2;
		/** In hard limit region **/
		final static public int HARD_LIMIT = 3;

		Point2D.Float angles;
		int panCW;
		int panCCW;
		int tiltUp;
		int tiltDown;
		boolean panTimeout;
		boolean panDirFault;
		boolean tiltTimeout;
		boolean tiltDirFault;

		boolean executing;
		boolean destination;
		boolean overrideSL;

		/**
		 * Accessor method.
		 *
		 * @param	ang	pan and tilt angles
		 */
		public void setAngles(Point2D.Float ang) {
			angles = ang;
		}

		/**
		 * Accessor method.
		 *
		 * @return	pan and tilt angles
		 */
		public Point2D.Float getAngles() {
			return angles;
		}

		/**
		 * Accessor method.
		 *
		 * @param	stat	clockwise status, one of the status constants
		 */
		public void setCWStatus(int stat) {
			panCW = stat;
		}

		/**
		 * Accessor method.
		 *
		 * @return	clockwise status, one of the status constants
		 */
		public int getCWStatus() {
			return panCW;
		}

		/**
		 * Accessor method.
		 *
		 * @param	stat	counter-clockwise status, one of the status constants
		 */
		public void setCCWStatus(int stat) {
			panCCW = stat;
		}

		/**
		 * Accessor method.
		 *
		 * @return	counter-clockwise status, one of the status constants
		 */
		public int getCCWStatus() {
			return panCCW;
		}

		/**
		 * Accessor method.
		 *
		 * @param	stat	up status, one of the status constants
		 */
		public void setUpStatus(int stat) {
			tiltUp = stat;
		}

		/**
		 * Accessor method.
		 *
		 * @return	up status, one of the status constants
		 */
		public int getUpStatus() {
			return tiltUp;
		}

		/**
		 * Accessor method.
		 *
		 * @param	stat	down status, one of the status constants
		 */
		public void setDownStatus(int stat) {
			tiltDown = stat;
		}

		/**
		 * Accessor method.
		 *
		 * @return	down status, one of the status constants
		 */
		public int getDownStatus() {
			return tiltDown;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	pan timeout flag
		 */
		public void setPanTimeout(boolean b) {
			panTimeout = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	pan timeout flag
		 */
		public boolean panTimeout() {
			return panTimeout;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	pan direction fault flag
		 */
		public void setPanDirFault(boolean b) {
			panDirFault = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	pan direction fault flag
		 */
		public boolean panDirFault() {
			return panDirFault;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	tilt timeout flag
		 */
		public void setTiltTimeout(boolean b) {
			tiltTimeout = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	tilt timeout flag
		 */
		public boolean tiltTimeout() {
			return tiltTimeout;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	tilt direction fault flag
		 */
		public void setTiltDirFault(boolean b) {
			tiltDirFault = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	tilt direction fault flag
		 */
		public boolean tiltDirFault() {
			return tiltDirFault;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	gimbal is executing flag
		 */
		public void setExecuting(boolean b) {
			executing = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	gimbal is executing flag
		 */
		public boolean executing() {
			return executing;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	angle is destination flag
		 */
		public void setDestination(boolean b) {
			destination = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	angle is destination flag
		 */
		public boolean destination() {
			return destination;
		}

		/**
		 * Accessor method.
		 *
		 * @param	b	override soft limits flag
		 */
		public void setOverrideSL(boolean b) {
			overrideSL = b;
		}

		/**
		 * Accessor method.
		 *
		 * @return	override soft limits flag
		 */
		public boolean overrideSL() {
			return overrideSL;
		}
	}

	/**
	 * Opens the connection to the specified address and port number.
	 *
	 * @param	addr	hostname or ip address of the gimbal
	 * @param	port	port number on which to make the connection
	 */
	public GimbalConnection(String addr, int port) throws UnknownHostException, IOException {
		socket = new Socket();
		socket.bind(null);
		socket.connect(new InetSocketAddress(addr, port), 2000);
		is = socket.getInputStream();
		os = socket.getOutputStream();
	}

	/**
	 * Close the connection to the gimbal.
	 */
	public void close() {
		try {
			socket.close();
			is.close();
			os.close();
		} catch(Exception e) {
			System.err.println("ERROR: Could not close connection: " + e);
		}
	}

	/**
	 * Send jog or keep alive command to gimbal and receive its status.
	 *
	 * @param	pan		speed of pan jog ranging from -1 to 1
	 * @param	tilt	speed of tilt jog ranging from -1 to 1
	 * @param	osl		whether or not to override soft limit during jog
	 * @return			gimbal status
	 */
	public  GimbalStatus jog(float pan, float tilt, boolean osl) throws IOException {
		return jog(pan, tilt, osl, false, false);
	}

	/**
	 * Send jog or keep alive command to gimbal and receive its status.
	 *
	 * @param	pan		speed of pan jog ranging from -1 to 1
	 * @param	tilt	speed of tilt jog ranging from -1 to 1
	 * @param	osl		whether or not to override soft limit during jog
	 * @param	stop	whether or not to stop execution
	 * @param	reset	whether or not to do a fault reset
	 * @return			gimbal status
	 */
	private GimbalStatus jog(float pan, float tilt, boolean osl, boolean stop, boolean reset) throws IOException {
		if(pan < -1)
			pan = -1;
		else if(pan > 1)
			pan = 1;
		if(tilt < -1)
			tilt = -1;
		else if(tilt > 1)
			tilt = 1;

		short[] pkt = {0,0,0,0,0,0,0};
		short pdir = 0;
		short tdir = 0;
		short pslo = 0;
		short tslo = 0;
		short ovsl = (short)(osl ? 0x04 : 0);
		short stp = (short)(stop ? 0x02 : 0);
		short res = (short)(reset ? 0x01 : 0);
		if(pan > 0)
			pdir = 0x80;
		else
			pan = Math.abs(pan);
		if(tilt > 0)
			tdir = 0x40;
		else
			tilt = Math.abs(tilt);
		/*if(pan <= 0.5) {
			tslo =0x10;
			pan *= 2;
		} else
		pan = (pan - 0.5)*2
		if(tilt <= 0.5) {
			pslo =0x08;
			tilt *= 2;
		} else
		tilt = (tilt - 0.5)*2*/
		pkt[0] = (short)(pdir | tdir | pslo | tslo | ovsl | stp | res); // flags
		pkt[1] = (short)Math.round(pan * 255);
		pkt[2] = (short)Math.round(tilt * 255);
		
		return buildStatus(sendPacket(0x31, pkt));
	}

	/**
	 * Builds the status object from the standard status packet.
	 *
	 * @param	pkt	raw packet containing gimbal status data
	 * @return		the built status object
	 */
	private GimbalStatus buildStatus(short[] pkt) {
		GimbalStatus ret = new GimbalStatus();
		ret.setAngles(new Point2D.Float((float)getValue24(pkt, 0)/100, (float)getValue24(pkt, 3)/100));
		short pstat = pkt[6];
		short tstat = pkt[7];
		short stat = pkt[8];

		// CW status
		if((pstat & 0x20) != 0)
			ret.setCWStatus(GimbalStatus.HARD_LIMIT);
		else if((pstat & 0x80) != 0)
			ret.setCWStatus(GimbalStatus.SOFT_LIMIT);
		else if((stat & 0x08) != 0)
			ret.setCWStatus(GimbalStatus.MOVING);
		else
			ret.setCWStatus(GimbalStatus.NONE);

		// CCW status
		if((pstat & 0x10) != 0)
			ret.setCCWStatus(GimbalStatus.HARD_LIMIT);
		else if((pstat & 0x40) != 0)
			ret.setCCWStatus(GimbalStatus.SOFT_LIMIT);
		else if((stat & 0x04) != 0)
			ret.setCCWStatus(GimbalStatus.MOVING);
		else
			ret.setCCWStatus(GimbalStatus.NONE);

		// Up status
		if((tstat & 0x20) != 0)
			ret.setUpStatus(GimbalStatus.HARD_LIMIT);
		else if((tstat & 0x80) != 0)
			ret.setUpStatus(GimbalStatus.SOFT_LIMIT);
		else if((stat & 0x02) != 0)
			ret.setUpStatus(GimbalStatus.MOVING);
		else
			ret.setUpStatus(GimbalStatus.NONE);

		// Down status
		if((tstat & 0x10) != 0)
			ret.setDownStatus(GimbalStatus.HARD_LIMIT);
		else if((tstat & 0x40) != 0)
			ret.setDownStatus(GimbalStatus.SOFT_LIMIT);
		else if((stat & 0x01) != 0)
			ret.setDownStatus(GimbalStatus.MOVING);
		else
			ret.setDownStatus(GimbalStatus.NONE);

		// Timeout/dir faults
		ret.setPanTimeout((pstat & 0x08) != 0);
		ret.setPanDirFault((pstat & 0x04) != 0);
		ret.setTiltTimeout((tstat & 0x08) != 0);
		ret.setTiltDirFault((tstat & 0x04) != 0);

		ret.setExecuting((stat & 0x40) != 0);
		ret.setDestination((stat & 0x20) != 0);
		ret.setOverrideSL((stat & 0x10) != 0);

		return ret;
	}

	/**
	 * Stop execution of the gimbal.
	 *
	 * @return	the gimbal status
	 */
	public GimbalStatus stop() throws IOException {
		return jog(0, 0, false, true, false);
	}

	/**
	 * Get the status of the gimbal, also can be used as a keep alive command
	 *
	 * @param	reset	do a fault reset
	 * @return			gimbal status
	 */
	public GimbalStatus getStatus(boolean reset) throws IOException {
		return jog(0, 0, false, false, reset);
	}

	/**
	 * Move to specified angles.
	 *
	 * @param	pan		pan angle
	 * @param	tilt	tilt angle
	 * @return			gimbal status, this should contain the destination angles
	 */
	public GimbalStatus moveToCoordinates(float pan, float tilt) throws IOException {
		short[] pkt = new short[6];
		setValue24(pkt, 0, Math.round(pan*100));
		setValue24(pkt, 3, Math.round(tilt*100));
		return buildStatus(sendPacket(0x33, pkt));
	}

	/**
	 * Move  gimbal to specified angles from current position.
	 * 
	 * @param	pan		pan delta angle
	 * @param	tilt	tilt delta angle
	 * @return			gimbal status, this should contain the destination angles
	 */
	public GimbalStatus moveToDeltaCoordinates(float pan, float tilt) throws IOException {
		short[] pkt = new short[6];
		setValue24(pkt, 0, Math.round(pan*100));
		setValue24(pkt, 3, Math.round(tilt*100));
		return buildStatus(sendPacket(0x34, pkt));
	}

	/**
	 * Move gimbal to home position (preset 31)
	 *
	 * @return	gimbal status
	 */
	public GimbalStatus moveToHome() throws IOException {
		return buildStatus(sendPacket(0x36, null));
	}

	/**
	 * Move to physical 0/0 position.
	 *
	 * @return	gimbal status
	 */
	public GimbalStatus moveToAbsolute00() throws IOException {
		return buildStatus(sendPacket(0x35, null));
	}

	/**
	 * Retreive soft limit value from the gimbal.
	 *
	 * @param	axis	axis/direction constant
	 * @return			the soft limit angle for the specified axis/direction
	 */
	public float getSoftLimit(short axis) throws IOException {
		short[] data = new short[1];
		data[0] = (short)(axis | 0x80);
		data = sendPacket(0x81, data);
		return (float)getValue24(data, 1)/100;
	}

	/**
	 * Sets the soft limit of the specified axis/direction to the current position.
	 *
	 * @param	axis	axis/direction constant
	 * @return			the soft limit angle for the specified axis/direction
	 */
	public float setSoftLimit(short axis) throws IOException {
		short[] data = new short[1];
		data[0] = axis;
		data = sendPacket(0x81, data);
		return (float)getValue24(data, 1)/100;
	}

	/**
	 * Retreives angle offset from the gimbal.
	 *
	 * @return	pan and tilt angle offsets
	 */
	public Point2D.Float getAngleOffsets() throws IOException {
		short[] ack = sendPacket(0x85, null);
		return new Point2D.Float((float)getValue24(ack, 0)/100, (float)getValue24(ack, 3)/100);
	}

	/**
	 * Sets the angle offsets.
	 *
	 * @param	pan		pan angle offset
	 * @param	tilt	tilt angle offset
	 */
	public void setAngleOffsets(float pan, float tilt) throws IOException {
		// Bounds checking
		if(pan < -180)
			pan = -180;
		else if(pan > 180)
			pan = 180;
		if(tilt < -90)
			tilt = -90;
		else if(tilt > 90)
			tilt = 90;

		// Build packet
		short[] pkt = new short[6];
		setValue24(pkt, 0, Math.round(100f*pan));
		setValue24(pkt, 3, Math.round(100f*tilt));
		sendPacket(0x80, pkt);
	}

	/**
	 * Set angle offsets to 0/0.
	 */
	public void clearAngleOffsets() throws IOException {
		sendPacket(0x84, null);
	}

	/**
	 * Sets the offsets such that the current position becomes 0/0.
	 */
	public void alignToCenter() throws IOException {
		sendPacket(0x82, null);
	}

	/**
	 * Sets the offsets such that the current position becomes the
	 * specified coordinates.
	 *
	 * @param	pan		pan coordinate
	 * @param	tilt	tilt coordinate
	 */
	public void alignToCoordinates(float pan, float tilt) throws IOException {
		// Bounds checking
		if(pan < -180)
			pan = -180;
		else if(pan > 180)
			pan = 180;
		if(tilt < -90)
			tilt = -90;
		else if(tilt > 90)
			tilt = 90;

		// Build packet
		short[] pkt = new short[6];
		setValue24(pkt, 0, Math.round(100f*pan));
		setValue24(pkt, 3, Math.round(100f*tilt));
		sendPacket(0x83, pkt);
	}

	/**
	 * Retreives the specified preset from the gimbal.
	 *
	 * @param	pn	preset number to retreive
	 * @return		the pan and tilt angles of the preset
	 */
	public Point2D.Float getPreset(int pn) throws IOException {
		if(pn < 0 || pn > NUM_PRESETS-1)
			return null;

		short[] data = new short[1];
		data[0] = (short)pn;
		data = sendPacket(0x40, data);

		if(data[0] != pn)
			return null;

		return new Point2D.Float((float)getValue24(data, 1)/100, (float)getValue24(data, 4)/100);
	}

	/**
	 * Moves the gimbal to the specified preset
	 *
	 * @param	pn	preset number to move to
	 */	 
	public void moveToPreset(int pn) throws IOException {
		short[] data = new short[1];
		data[0] = (short)pn;
		sendPacket(0x32, data);
	}

	/**
	 * Save the specified coordinates as a preset.
	 *
	 * @param	pn		preset number to which to save the coordinates
	 * @param	pan		pan angle of the preset
	 * @param	tilt	tilt angle of the preset
	 */
	public void saveCoordinatesAsPreset(int pn, float pan, float tilt) throws IOException {
		short[] pkt = new short[7];
		pkt[0] = (short)pn;
		setValue24(pkt, 1, Math.round(100f*pan));
		setValue24(pkt, 4, Math.round(100f*tilt));
		sendPacket(0x41, pkt);
	}

	/**
	 * Saves the current position as a preset.
	 *
	 * @param	pn	preset number to which to save the current position
	 */
	public void setCurrentPositionAsPreset(int pn) throws IOException {
		short[] data = new short[1];
		data[0] = (short)pn;
		sendPacket(0x42, data);
	}

	/**
	 * Sends the packet to the gimbal and handles the receipt of the
	 * acknowledgement packet, which is returned.
	 *
	 * @param	cmd		command number
	 * @param	data	packet to send where each short should only be a byte
	 * @return			the acknowledgement packet where each short is a byte
	 */
	private short[] sendPacket(int cmd, short[] data) throws IOException {
		int i;

		// Compute LRC
		short LRC = (short)cmd;
		if(data != null) {
			for(i = 0; i < data.length; i++)
				LRC ^=  data[i];
		}

		// Add escape characters if necessary
		// Need dynamic array for this
		ArrayList<Short> barr = new ArrayList<Short>();
		if(data != null) {
			for(i = 0; i < data.length; i++)
				barr.add(new Short(data[i]));
		}
		barr.add(new Short(LRC));
		for(i = 0; i <  barr.size(); i ++) {
			for(int j = 0; j < controlChars.length; j++) {
				if(barr.get(i).shortValue() == controlChars[j]) {
					barr.set(i, new Short((short)(controlChars[j] | 0x80)));
					barr.add(i, new Short(controlChars[ESCAPE_CHAR]));
					i++;
				}
			}
		}

		// Convert to byte array
		byte[] bdata = new byte[barr.size() + 4];
		bdata[0] = controlChars[STX_CHAR]; // start of text
		bdata[1] = 0x00; // identity
		bdata[2] = (byte)cmd;
		bdata[barr.size() + 3] = controlChars[ETX_CHAR]; // end of text
		for(i = 0; i < barr.size(); i++)
			bdata[i+3] = (byte)(0xFF & barr.get(i).shortValue());

		// Send packet
		//System.out.printf("Packet sent: ");
		//printPacket(bdata);
		os.write(bdata);

		// Now need to wait for a response
		ArrayList<Short> buff = new ArrayList<Short>();
		boolean recving = false;
		final int timeout = 400000;
		int to;
		for(to = 0; to < timeout; to++) {
			if(is.available() > 0) {
				if(!recving && is.read() != controlChars[ACK_CHAR])
					continue;
				if(!recving) {
					buff.add(new Short(controlChars[ACK_CHAR]));
					recving = true;
					continue;
				}

				int next = is.read();
				buff.add(new Short((short)next));
				if(next == controlChars[ETX_CHAR])
					break;
				to = 0;
			}
		}
		// Timed out?
		if(to == timeout)
			throw new IOException("Receipt of acknowledgement timed out");

		//System.out.printf("Ack recvd: ");
		//printPacket(buff);

		// Check for escape characters and remove them and correct byte and check the checksum
		LRC = 0;
		boolean justEscaped = false;
		for(i = 2; i < buff.size()-1; i++) {
			if(buff.get(i) == controlChars[ESCAPE_CHAR] && !justEscaped) {
				// Remove esscape char and correct byte
				buff.remove(i);
				buff.set(i, new Short((short)(buff.get(i) & 0x7F)));
				i--;
				justEscaped = true;
			} else {
				justEscaped = false;
				if(i == buff.size()-2) {
					if(buff.get(i) != LRC)
						throw new IOException("Invalid checksum in acknowledgement packet");
				} else
					LRC ^= buff.get(i);
			}
		}

		// Verify command
		if(buff.get(2) != cmd)
			throw new IOException("Acknowledgement received for incorrect command");

		// Have the complete packet, strip off unecessary bytes
		short[] pkt = new short[buff.size() - 5];
		for(i = 3; i < buff.size() - 2; i++)
			pkt[i-3] = buff.get(i);

		//System.out.printf("Ack recvd: ");
		//printPacket(pkt);
		return pkt;
	}

	/**
	 * Prints the raw data from a packet. This is used for testing purposes.
	 *
	 * @param	pkt	packet data to print
	 */
	private static void printPacket(byte[] pkt) {
		for(int i = 0; i < pkt.length; i++) {
			System.out.printf("%02X ", pkt[i]);
			if(((i+1) % 16) == 0)
				System.out.printf("\n");
		}
		System.out.printf("\n");
	}

	/**
	 * Prints the raw data from a packet. This is used for testing purposes.
	 *
	 * @param	pkt	packet data to print in which each short is just a byte
	 */
	private static void printPacket(short[] pkt) {
		for(int i = 0; i < pkt.length; i++) {
			System.out.printf("%02X ", pkt[i]);
			if(((i+1) % 16) == 0)
				System.out.printf("\n");
		}
		System.out.printf("\n");
	}

	/**
	 * Prints the raw data from a packet. This is used for testing purposes.
	 *
	 * @param	pkt	packet data to print in which each short in the <code>ArrayList</code> is just a byte
	 */
	private static void printPacket(ArrayList<Short> buff) {
		for(int i = 0; i < buff.size(); i++) {
			System.out.printf("%02X ", buff.get(i));
			if(((i+1) % 16) == 0)
				System.out.printf("\n");
		}
		System.out.printf("\n");
	}

	/**
	 * Extracts a 24-bit integer from packet data.
	 *
	 * @param	data	packet data in which each short is a byte
	 * @param	idx		index of the 3-byte integer in the packet
	 * @return			integer value
	 */
	private int getValue24(short[] data, int idx) {
		int val = data[idx];
		val |= data[idx+1] << 8;
		val |= data[idx+2] << 16;

		// Acount for two's compliment negative values
		if((val & 0x800000) != 0)
			val = -((~val & 0xFFFFFF) + 1);
		return val;
	}

	/**
	 * Sets a 24-bit integer in the packet from an integer value using
	 * the correct byte order (little endian).
	 *
	 * @param	data	packet data in which each short is a byte
	 * @param	idx		index in the packet at which to write the integer value
	 * @param	val		integer value to write
	 */
	private void setValue24(short[] data, int idx, int val) {
		// Negative numbers are automatically handled here
		data[idx] = (short)(val & 0xFF);
		data[idx+1] = (short)((val & 0xFF00) >> 8);
		data[idx+2] = (short)((val & 0xFF0000) >> 16);
	}

	Socket socket;
	InputStream is;
	OutputStream os;

	// Special characters in protocol
	final static int STX_CHAR = 0;
	final static int ETX_CHAR = 1;
	final static int ACK_CHAR = 2;
	final static int NACK_CHAR = 3;
	final static int ESCAPE_CHAR = 4;
	final static byte[] controlChars = {0x02, 0x03, 0x06, 0x15, 0x1B};

	/** Value passed to hold pan and/or tilt when moving to absolute coordinates. **/
	final static public float HOLD_VALUE = (float)999.99;

	/** Clockwise soft limit constant. **/
	final static public short SL_CW = 0x00;
	/** Counter-clockwise soft limit constant. **/
	final static public short SL_CCW = 0x01;
	/** Up soft limit constant. **/
	final static public short SL_UP = 0x02;
	/** Down soft limit constant. **/
	final static public short SL_DOWN = 0x03;

	/** Number of available presets. **/
	final static public short NUM_PRESETS = 32;
}

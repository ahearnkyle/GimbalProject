/***************************************
 * Class: GimbalJoystickConfig
 * Author: Dan Whitman
 * 
 * Class which contains the configuration
 * information for a gimbal joystick.
 *
 ***************************************/
package afit.util;

import java.io.Serializable;
import afit.util.GimbalConnection;

/**
 * Encapsulates the configuration of a joystick
 * for controlling a gimbal.
 */
public class GimbalJoystickConfig
	implements Serializable
{	
	final int N_AXIS_BUTTONS = 8;
	// Button and axis constants
	/** Pan axis constant **/
	public static final int AXIS_PAN = 0;
	/** Tilt axis constant **/
	public static final int AXIS_TILT = 1;
	/** Sensitivity axis constant **/
	public static final int AXIS_SENS = 2;
	/** Previous gimbal button constant **/
	public static final int BTN_PREV = 3;
	/** Next gimbal button constant **/
	public static final int BTN_NEXT = 4;
	/** All gimbals button constant **/
	public static final int BTN_ALL = 5;
	/** Override soft limits button constant **/
	public static final int BTN_SOFT_LIM = 6;
	/** Previous gimbal button constant **/
	public static final int BTN_QUIT = 7;

	/** Joystick x-axis mask. **/
	public static final int JS_AXIS_X = 0x01;
	/** Joystick y-axis mask. **/
	public static final int JS_AXIS_Y = 0x02;
	/** Joystick z-axis mask. **/
	public static final int JS_AXIS_Z = 0x04;
	/** Joystick u-axis mask. **/
	public static final int JS_AXIS_U = 0x08;
	/** Joystick v-axis mask. **/
	public static final int JS_AXIS_V = 0x10;
	/** Joystick r-axis mask. **/
	public static final int JS_AXIS_R = 0x20;

	int[] axisButtons;
	int[] presetButtons;

	/**
	 * Constructs an empty object.
	 */
	public GimbalJoystickConfig() {
		axisButtons = new int[N_AXIS_BUTTONS];
		for(int i = 0; i < N_AXIS_BUTTONS; i++)
			axisButtons[i] = 0;
		
		presetButtons = new int[GimbalConnection.NUM_PRESETS];
		for(int i = 0; i < GimbalConnection.NUM_PRESETS; i++)
			presetButtons[i] = 0;
	}

	/**
	 * Sets an axis or button.
	 *
	 * @param	idx		which axis or button (should be one of the constants)
	 * @param	value	axis or button mask
	 */
	public void setAxisButton(int idx, int value) {
		axisButtons[idx] = value;
	}

	/**
	 * Gets an axis or button mask.
	 *
	 * @param	idx	which axis or button (should be one of the constants)
	 * @return		the requested axis or button mask
	 */
	public int getAxisButton(int idx) {
		return axisButtons[idx];
	}

	/**
	 * Sets a preset button mask. If the button is already assigned
	 * to another function, it is not set. Unless that function was
	 * another preset in which case the button is assigned to the new
	 * preset and no button to the previous preset.
	 *
	 * @param	idx		preset number to be associated with the button press
	 * @param	value	button mask of the button to which to assign to the preset
	 * @return			<code>true</code> if the button was set and <code>false</code> if the button is assigned to another function.
	 */
	public boolean setPresetButton(int idx, int value) {
		if(value > 0) {
			for(int i = 0; i < N_AXIS_BUTTONS; i++) {
				if(axisButtons[i] == value)
					return false;
			}
			
			for(int i = 0; i < GimbalConnection.NUM_PRESETS; i++) {
				if(presetButtons[i] == value)
					presetButtons[i] = 0;
			}
		}

		presetButtons[idx] = value;
		return true;
	}

	/**
	 * Gets the button mask assigned to a preset.
	 *
	 * @param	idx	preset number
	 * @return		button mask or 0 if no button is assigned
	 */
	public int getPresetButton(int idx)	{
		return presetButtons[idx];
	}

	/**
	 * Returns which button was pressed given a button mask.
	 *
	 * @param	mask	joystick button mask
	 * @return			the constant indicating the function pressed or -1 if no functino button was pressed
	 */
	public int getButtonPressed(int mask) {
		if((mask & axisButtons[BTN_PREV]) != 0)
			return BTN_PREV;
		if((mask & axisButtons[BTN_NEXT]) != 0)
			return BTN_NEXT;
		if((mask & axisButtons[BTN_ALL]) != 0)
			return BTN_ALL;
		if((mask & axisButtons[BTN_SOFT_LIM]) != 0)
			return BTN_SOFT_LIM;
		if((mask & axisButtons[BTN_QUIT]) != 0)
			return BTN_QUIT;

		return -1;
	}
}

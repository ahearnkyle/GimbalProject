/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package afit;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.MouseListener;
import java.util.EventListener;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;

/**
 * List component that shows preset data and allows the user to
 * select one and only one preset.
 *
 * @author dwhitman
 */
public class PresetList extends JScrollPane {
	/**
	 * Cell renderer for the preset list component
	 */
	static private class PresetCellRenderer extends JPanel implements ListCellRenderer {
		JLabel numLabel, panLabel, tiltLabel, jbLabel;

		/**
		 * Constructs the cell renderer
		 */
		PresetCellRenderer() {
			setLayout(new GridLayout(1, 4));
			numLabel = new JLabel();
			panLabel = new JLabel();
			tiltLabel = new JLabel();
			jbLabel = new JLabel();
			numLabel.setOpaque(true);
			panLabel.setOpaque(true);
			tiltLabel.setOpaque(true);
			jbLabel.setOpaque(true);
			add(numLabel);
			add(panLabel);
			add(tiltLabel);
			add(jbLabel);
		}
	   
		/**
		 * Updates a row of cells.
		 *
		 * @param	list			list object with which the renderer is associated
		 * @param	value			<code>String</code> array with 4 elements containing the data for the list
		 * @param	index			index of current row
		 * @param	isSelected		whether or not the current row is selected
		 * @param	cellHasFocus	whether or not the current row has focus
		 * @return					the cell renderer
		 */
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
			numLabel.setText(((String[])value)[0]);
			panLabel.setText(((String[])value)[1]);
			tiltLabel.setText(((String[])value)[2]);
			jbLabel.setText(((String[])value)[3]);

			if(isSelected) {
				numLabel.setBackground(list.getSelectionBackground());
				numLabel.setForeground(list.getSelectionForeground());
				panLabel.setBackground(list.getSelectionBackground());
				panLabel.setForeground(list.getSelectionForeground());
				tiltLabel.setBackground(list.getSelectionBackground());
				tiltLabel.setForeground(list.getSelectionForeground());
				jbLabel.setBackground(list.getSelectionBackground());
				jbLabel.setForeground(list.getSelectionForeground());
			} else {
				numLabel.setBackground(list.getBackground());
				numLabel.setForeground(list.getForeground());
				panLabel.setBackground(list.getBackground());
				panLabel.setForeground(list.getForeground());
				tiltLabel.setBackground(list.getBackground());
				tiltLabel.setForeground(list.getForeground());
				jbLabel.setBackground(list.getBackground());
				jbLabel.setForeground(list.getForeground());
			}

			setEnabled(list.isEnabled());
			setFont(list.getFont());
			return this;
		}
	}

	JList list;

	/**
	 * Constructs the preset list.
	 */
	public PresetList() {
		super();
		list = new JList();
		list.setCellRenderer(new PresetCellRenderer());
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        list.addMouseListener(new java.awt.event.MouseAdapter() {
			@Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listMouseClicked(evt);
            }
        });

		setViewportView(list);
	}

	/**
	 * Event handler that handles mouse clicks on the list
	 * and passes them to listeners of this component.
	 *
	 * @param	evt	event object
	 */
	private void listMouseClicked(java.awt.event.MouseEvent evt) {
		// Forward event to control listeners
		MouseListener[] ls = getMouseListeners();

		for(int i = 0; i < ls.length; i++) {
			ls[i].mouseClicked(evt);
		}
	}

	/**
	 * Sets the list data.
	 *
	 * @param	data	list data in an x by 4 array
	 */
	public void setListData(String[][] data) {
		list.setListData(data);
	}

	/**
	 * Returns the index of the selected list item.
	 *
	 * @return	index of the currently selected item or -1 if no item is selected
	 */
	public int getSelectedIndex() {
		return list.getSelectedIndex();
	}

	/**
	 * Sets the currently selected list item.
	 *
	 * @param	idx	index of the item to be selected
	 */
	public void setSelectedIndex(int idx) {
		list.setSelectedIndex(idx);
	}
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package afit;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Polygon;
import javax.swing.JPanel;
import java.awt.event.MouseEvent;
import java.awt.geom.*;

/**
 * Read-only component that displays an angle, soft and hard limits,
 * and a destination angle graphically with an analog dial. Allows
 * for a display offset such that 0 degrees is at some offset from
 * the positive x-axis. Also allows for an offset that changes the
 * number labels.
 *
 * @author dwhitman
 */
public class AngleDisplayPanel extends JPanel {
	final int tickInc = 5;
	final int labelInc = 45;
	float displayOffset;
	float hardLimL;
	float hardLimU;
	boolean flipSign;
	float softLimL;
	float softLimU;
	float angle;
	float destAngle;
	float angleOffset;

	/**
	 * Constructs angle display panel with default options.
	 * Default options are:
	 * <ul>
	 * <li>0 degrees offset, so 0 degrees is the positive x-axis</li>
	 * <li>0 degrees display offset</li>
	 * <li>Hard limits from -90 to 90 degrees</li>
	 * <li>Soft limits from 0 to 0 degrees </li>
	 * <li>Normal orientation</li>
	 * <li>Angle set to 0 degrees</li>
	 * <li>Destination angle set to 0 degrees</li>
	 * </ul>
	 */
	public AngleDisplayPanel() {
		angleOffset = 0;
		displayOffset = 0;
		flipSign = false;
		hardLimL = -90;
		hardLimU = 90;
		softLimL = 0;
		softLimU = 0;
		angle = 0;
		destAngle = 0;
	}

	/**
	 * Constructs angle display panel with specified options.
	 * Other options default to:
	 * <ul>
	 * <li>0 degrees display offset</li>
	 * <li>Soft limits from 0 to 0 degrees </li>
	 * <li>Angle set to 0 degrees</li>
	 * <li>Destination angle set to 0 degrees</li>
	 * </ul>
	 *
	 * @param	offset	angle offset from the positive x-axis
	 * @param	hardL	lower hard limit
	 * @param	hardU	upper hard limit
	 * @param	flip	<code>false</code> for normal orientation, <code>true</code> for reverse orientation.
	 */
	public AngleDisplayPanel(float offset, float hardL, float hardU, boolean flip) {
		angleOffset = 0;
		displayOffset = offset;
		flipSign = flip;
		hardLimL = hardL;
		hardLimU = hardU;
		softLimL = 0;
		softLimU = 0;
		angle = 0;
		destAngle = 0;
	}

	/**
	 * Draws the angle display.
	 *
	 * @param	g	graphics to which to display
	 */
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g); 

		Graphics2D g2d = (Graphics2D)g;

		Dimension size = getSize();
		Insets insets = getInsets();
		int width =  size.width - insets.left - insets.right + 1;
		int height =  size.height - insets.top - insets.bottom + 1;
		Point2D.Float origin = new Point2D.Float((float)width/2, (float)height/2);
		
		float rad = (float)Math.min(width, height)/2f;
		Rectangle2D.Float boundRect;

		// Draw soft limit
		if(softLimL != softLimU) {
			boundRect = getRectFromRad(origin, rad*0.64f);
			g2d.setStroke(new BasicStroke(4));
			g2d.setColor(Color.yellow);
			g2d.draw(new Arc2D.Float(boundRect, trueAngle(softLimL), angleDiff(softLimU, softLimL), Arc2D.OPEN));
		}

		// Draw normal and hard limits
		boundRect = getRectFromRad(origin, rad*0.6f);
		g2d.setStroke(new BasicStroke(4));
		g2d.setColor(Color.red);
		g2d.draw(new Arc2D.Float(boundRect, trueAngle(hardLimL), angleDiff(hardLimU, hardLimL), Arc2D.OPEN));
		g2d.setColor(Color.green);
		g2d.draw(new Arc2D.Float(boundRect, trueAngle(hardLimU), angleDiff(hardLimL+360, hardLimU), Arc2D.OPEN));

		// Draw tick marks and labels
		g2d.setStroke(new BasicStroke(1));
		g2d.setColor(Color.black);
		for(int ango = 180; ango > -180; ango -= tickInc) {
			int ang = (int)trueAngle((float)ango);
			int dispang = ango;
			float r1, r2;

			if(ang % labelInc == 0) {
				// Big tick and label
				r1 = rad*0.615f;
				r2 = rad*0.74f;
				Point2D.Float textPoint = getPointAtRadius(origin, -ang, rad*0.77f);
				adjustTextPosition(textPoint, dispang, ang);
				g2d.drawString((new Integer(dispang)).toString(), Math.round(textPoint.getX()), Math.round(textPoint.getY()));
			} else {
				// Little tick
				r1 = rad*0.66f;
				r2 = rad*0.68f;
			}

			// Draw tick
			g2d.draw(new Line2D.Float(getPointAtRadius(origin, ang, r1), getPointAtRadius(origin, ang, r2)));
		}

		// Draw needles
		g2d.setColor(new Color(150,0,150));
		drawNeedle(g2d, origin, rad, destAngle);
		g2d.setColor(new Color(0,0,120));
		drawNeedle(g2d, origin, rad, angle);

		// Draw center circle
		final float centerRad = rad*0.03f;
		g2d.setColor(Color.black);
		g2d.fillOval((int)Math.round(origin.getX()-centerRad), (int)Math.round(origin.getY()-centerRad), Math.round(centerRad*2), Math.round(centerRad*2));
	}

	/**
	 * Draws a needle i nthe current color.
	 *
	 * @param	g2d		graphics to which to draw the needle
	 * @param	origin	point in the graphics representing the center of the display
	 * @param	rad		radius of the needle
	 * @param	angle	angle at which to draw the needle
	 */
	private void drawNeedle(Graphics2D g2d, Point2D.Float origin, float rad, float angle) {
		final float needleY = rad*0.05f;
		Point2D.Float[] needlePoints = new Point2D.Float[3];
		needlePoints[0] = new Point2D.Float(-rad*0.05f, needleY);
		needlePoints[1] = new Point2D.Float(rad*0.65f, 0);
		needlePoints[2] = new Point2D.Float(-rad*0.05f, -needleY);
		AffineTransform rot = AffineTransform.getTranslateInstance(origin.getX(), origin.getY());
		rot.concatenate(AffineTransform.getRotateInstance(Math.toRadians(-trueAngle(angle))));
		rot.transform(needlePoints, 0, needlePoints, 0, 3);
		
		Polygon needle = new Polygon();
		for(int i = 0; i < needlePoints.length; i++)
			needle.addPoint((int)Math.round(needlePoints[i].getX()), (int)Math.round(needlePoints[i].getY()));
		g2d.fillPolygon(needle);
	}		

	/**
	 * Given the actual and display angles, calculates the offset
	 * to place the text at the correct position.
	 *
	 * @param	textPoint	point where the text should be placed, which will be modified to the correct location
	 * @param	ango		text display angle
	 * @param	ang			actual angle
	 */
	private void adjustTextPosition(Point2D.Float textPoint, float ango, float ang) {
		final float charW = 8;
		final float charH = 8;
		float offsetV = 0;
		float offsetH = 0;
		
		// Vertical adjustment
		float sin = (float)Math.sin(Math.toRadians(ang));
		if(Math.round(sin) == -1)
			offsetV = charH;
		else if(Math.round(sin) == 0)
			offsetV = charH/2;

		// Horizontal adjustment
		float nchars = 1;
		if(Math.abs(ango) >= 100)
			nchars = 3;
		else if(Math.abs(ango) >= 10)
			nchars = 2;
		if(ango < 0)
			nchars++;
		float w = charW*nchars;
		float cos = (float)Math.cos(Math.toRadians(ang));
		if(Math.round(cos) == -1)
			offsetH = -w;
		else if(Math.round(cos) == 0)
			offsetH = -w/2;
		
		textPoint.setLocation(textPoint.getX()+offsetH, textPoint.getY()+offsetV);
	}

	/**
	 * Locates a point at an angle and radius from an origin. Essentially
	 * a conversion from polar to cartesian coordinates.
	 *
	 * @param	origin	origin point
	 * @param	ang		angle
	 * @param	rad		radius
	 */
	private Point2D.Float getPointAtRadius(Point2D.Float origin, float ang, float rad) {
		AffineTransform rot = AffineTransform.getRotateInstance(Math.toRadians(ang));
		Point2D.Float rotPoint = (Point2D.Float)rot.transform(new Point2D.Float(rad,0), null);
		rotPoint.setLocation(rotPoint.getX() + origin.getX(), rotPoint.getY() + origin.getY());
		return rotPoint;
	}

	/**
	 * Calculates the rectangle that encloses a circle of specified radius
	 *
	 * @param	origin	origin point
	 * @param	rad		radius of the circle
	 * @return			enclosing rectangle
	 */
	private Rectangle2D.Float getRectFromRad(Point2D.Float origin, float rad) {
		return new Rectangle2D.Float((float)origin.getX() - rad, (float)origin.getY() - rad, 2*rad, 2*rad);
	}

	/**
	 * Converts an angle to the actual angle from the x-axis of the display,
	 * taking into account the offsets and orientation.
	 *
	 * @param	ang	angle
	 * @return		angle from the x-axis o nthe display
	 */
	private float trueAngle(float ang) {
		return (flipSign ? -ang + displayOffset + angleOffset : ang + displayOffset - angleOffset);
	}

	/**
	 * Computes the difference between two angles taking into account
	 * the orientation.
	 *
	 * @param	a1	lower angle
	 * @param	a2	upper angle
	 * @return		the difference between the angles
	 */
	private float angleDiff(float a1, float a2) {
		return (flipSign ? a2 - a1 : a1 - a2);
	}

	/**
	 * Determines if an angle is in a range of angles.
	 *
	 * @param	limL	lower limit of angle range
	 * @param	lumU	upper limit of angle range
	 * @param	out		<code>true</code> if the angle should be outside of the range
	 * @param	ang		angle
	 * @return			the angle if it is in (or out) of the range or the closest range
	 *					limit if outside (or inside) of it.
	 */
	private float angleInRange(float limL, float limU, boolean out, float ang) {
		limL = wrapAngle(limL);
		limU = wrapAngle(limU);
		ang = wrapAngle(ang);
		boolean kick = false;

		if(limL < limU) {
			if(ang > limL && ang < limU) {
				// In the range
				kick = out;
			} else if(!out) {
				kick = true;
			}
		} else {
			// The range wraps around the discontinuity
			if(ang > limL || ang < limU) {
				// In the range
				kick = out;
			} else if(!out) {
				kick = true;
			}
		}
		
		if(kick) {
			if(Math.abs(ang - limL) < Math.abs(ang - limU))
				return limL;
			else
				return limU;
		} else
			return ang;
	}

	/**
	 * Sets the angle offset.
	 *
	 * @param	offset	angle offset
	 */
	public void setAngleOffset(float offset) {
		angleOffset = offset;
		repaint();
	}

	/**
	 * Sets the soft limit (yellow) angle range.
	 *
	 * @param	slL	lower soft limit
	 * @param	slU	upper soft limit
	 */
	public void setSoftLimits(float slL, float slU) {
		softLimL = slL;
		softLimU = slU;
		repaint();
	}

	/**
	 * Brings an angle within the range of -180 to 180 degrees.
	 *
	 * @param	ang	angle
	 * @return		equivalent angle in the base range
	 */
	public float wrapAngle(float ang) {
		while(ang <= -180 || ang > 180) {
			if(ang <= -180)
				ang += 360;
			else if(ang > 180)
				ang -= 360;
		}

		return ang;
	}

	/**
	 * Sets the current or destination angle (needles).
	 *
	 * @param	ang		angle
	 * @param	dest	<code>true</code> if setting the destination angle
	 * @return			the angle in the base range
	 */
	public float setAngle(float ang, boolean dest) {
		// Apply limits (this will also wrap)
		ang = wrapAngle(ang);

		if(dest)
			destAngle = ang;
		else
			angle = ang;
		repaint();
		return ang;
	}

	/**
	 * Retrieves the current or destination angle.
	 *
	 * @param	dest	<code>true</code> if the destination angle is desired
	 * @return			the requested angle within the base range
	 */
	public float getAngle(boolean dest) {
		if(dest)
			return destAngle;
		else
			return angle;
	}

	/**
	 * Adds (or subtracts) from the current or destination angle.
	 *
	 * @param	delt	amount to add to specified angle (negative subtracts)
	 * @param	dest	<code>true</code> if modifying the destination angle
	 * @return			the modified angle within the base range
	 */
	public float changeAngle(float delt, boolean dest) {
		if(dest)
			return setAngle(destAngle + delt, dest);
		else
			return setAngle(angle + delt, dest);
	}
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package afit;

import java.awt.AWTEvent;
import java.awt.EventQueue;
import javax.swing.JOptionPane;

/**
 * This class is used so that exceptions can be passed out and a
 * messsage box displayed.
 *
 * @author dwhitman
 */
public class EventQueueProxy extends EventQueue {

	/**
	 * Dispatches an event.
	 *
	 * @param	newEvent	event object
	 */
    @Override
	protected void dispatchEvent(AWTEvent newEvent) {
		try {
			super.dispatchEvent(newEvent);
		} catch(NumberFormatException nfe) {
			JOptionPane.showMessageDialog(null, "The number has an invalid format.", "Incorrect Format", JOptionPane.ERROR_MESSAGE);
		} catch(Throwable t) {
			t.printStackTrace();
			String message = t.getMessage();
			
			if (message == null || message.length() == 0) {
				message = "Fatal: " + t.getClass();
			}
			
			JOptionPane.showMessageDialog(null, message, "General Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
